<?php
include '../conexion.php';
$id = $_POST['id'];
$estado = $_POST['estado'];
$query = "UPDATE tareas SET estado='$estado' WHERE id=$id";
mysqli_query($conn, $query);
echo 'ok';
?>