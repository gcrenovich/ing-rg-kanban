<?php include 'conexion.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Kanban Departamental</title>
  <link href="https://cdn.jsdelivr.net/npm/@picocss/pico@1/css/pico.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.0/Sortable.min.js"></script>
  <style>
    .kanban-board { display: flex; gap: 1rem; overflow-x: auto; margin-top: 2rem; }
    .kanban-column { flex: 1; min-width: 250px; background: #f4f4f4; border-radius: 6px; padding: 1rem; }
    .kanban-column h4 { margin-top: 0; border-bottom: 1px solid #ccc; padding-bottom: 0.5rem; }
    .task { padding: 0.5rem; margin: 0.5rem 0; border-radius: 4px; background: #fff; border: 1px solid #ccc; }
    .urgencia-alta { background: #ffe0e0; }
    .urgencia-media { background: #fff8d6; }
    .urgencia-normal { background: #f4f4f4; }
  </style>
</head>
<body>
<nav class="container-fluid">
  <ul><li><strong>Kanban</strong></li></ul>
  <ul>
    <li><a href="equipos.php">ABM Equipos</a></li>
    <li><a href="usuarios.php">ABM Usuarios</a></li>
  </ul>
</nav>

<main class="container">
  <h2>Tablero Kanban</h2>
  <div class="kanban-board">
    <?php
    $estados = ['pendiente', 'progreso', 'hecho'];
    foreach ($estados as $estado) {
      echo "<div class='kanban-column' id='$estado'><h4>" . ucfirst($estado) . "</h4>";
      $query = mysqli_query($conn, "SELECT * FROM tareas WHERE estado='$estado'");
      while($t = mysqli_fetch_assoc($query)) {
        $urgencia = "urgencia-" . $t['urgencia'];
        echo "<div class='task $urgencia' data-id='{$t['id']}'>";
        echo "<strong>{$t['descripcion']}</strong><br><small>{$t['tipo']} - {$t['asignado']}</small>";
        echo "</div>";
      }
      echo "</div>";
    }
    ?>
  </div>
</main>

<script>
  ['pendiente', 'progreso', 'hecho'].forEach(function(col) {
    new Sortable(document.getElementById(col), {
      group: 'kanban',
      animation: 150,
      onAdd: function (evt) {
        const id = evt.item.dataset.id;
        const nuevoEstado = evt.to.id;
        fetch('ajax/actualizar_estado.php', {
          method: 'POST',
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          body: `id=${id}&estado=${nuevoEstado}`
        });
      }
    });
  });
</script>
</body>
</html>