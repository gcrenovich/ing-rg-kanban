CREATE DATABASE IF NOT EXISTS kanban_db;
USE kanban_db;

CREATE TABLE IF NOT EXISTS equipos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  rol ENUM('miembro', 'jefe_equipo', 'admin') DEFAULT 'miembro',
  equipo_id INT,
  FOREIGN KEY (equipo_id) REFERENCES equipos(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS tareas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  descripcion TEXT NOT NULL,
  tipo ENUM('diaria', 'conplazo') NOT NULL,
  inicio DATE DEFAULT NULL,
  fin DATE DEFAULT NULL,
  estado ENUM('pendiente', 'progreso', 'hecho') DEFAULT 'pendiente',
  equipo_id INT,
  asignado VARCHAR(100),
  urgencia ENUM('normal', 'media', 'alta') DEFAULT 'normal',
  FOREIGN KEY (equipo_id) REFERENCES equipos(id) ON DELETE SET NULL
);

INSERT INTO equipos (nombre) VALUES ('Equipo A'), ('Equipo B');
INSERT INTO usuarios (nombre, rol, equipo_id) VALUES 
('Ana Rodríguez', 'jefe_equipo', 1),
('Carlos Pérez', 'miembro', 1),
('Laura Gómez', 'miembro', 2),
('José Martínez', 'admin', NULL);