CREATE DATABASE IF NOT EXISTS kanban_db;
USE kanban_db;

CREATE TABLE IF NOT EXISTS equipos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS tareas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  descripcion TEXT NOT NULL,
  tipo ENUM('diaria', 'conplazo') NOT NULL,
  inicio DATE DEFAULT NULL,
  fin DATE DEFAULT NULL,
  estado ENUM('pendiente', 'progreso', 'hecho') DEFAULT 'pendiente',
  equipo_id INT,
  asignado VARCHAR(100),
  FOREIGN KEY (equipo_id) REFERENCES equipos(id)
);

INSERT INTO equipos (nombre) VALUES ('Equipo A'), ('Equipo B');