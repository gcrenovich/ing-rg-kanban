<?php include 'conexion.php'; ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Kanban Local</title>
  <link href="https://cdn.jsdelivr.net/npm/@picocss/pico@1/css/pico.min.css" rel="stylesheet" />
  <style>
    .kanban-board { display: flex; gap: 1rem; overflow-x: auto; padding: 1rem 0; }
    .kanban-column { flex: 1; min-width: 250px; background: #f4f4f4; border-radius: 6px; padding: 1rem; }
    .kanban-column h4 { border-bottom: 1px solid #ccc; padding-bottom: 0.5rem; }
    .task { background: #fff; padding: 0.5rem; margin: 0.5rem 0; border: 1px solid #ccc; border-radius: 4px; }
    small { font-size: 0.8rem; color: gray; display: block; }
  </style>
</head>
<body>
  <main class="container">
    <h2>Crear Nueva Tarea</h2>
    <form action="guardar_tarea.php" method="POST" class="grid">
      <input type="text" name="descripcion" placeholder="Descripción" required>
      <select name="tipo">
        <option value="diaria">Diaria</option>
        <option value="conplazo">Con plazo</option>
      </select>
      <input type="date" name="inicio" placeholder="Inicio">
      <input type="date" name="fin" placeholder="Fin">
      <select name="equipo_id">
        <?php $res = mysqli_query($conn, "SELECT * FROM equipos"); while($eq = mysqli_fetch_assoc($res)) {
          echo "<option value='{$eq['id']}'>{$eq['nombre']}</option>";
        } ?>
      </select>
      <input type="text" name="asignado" placeholder="Asignado a">
      <button type="submit">Agregar</button>
    </form>

    <div class="kanban-board">
      <?php
        $estados = ['pendiente', 'progreso', 'hecho'];
        foreach ($estados as $estado) {
          echo "<div class='kanban-column'><h4>" . ucfirst($estado) . "</h4>";
          $tareas = mysqli_query($conn, "SELECT * FROM tareas WHERE estado='$estado'");
          while($t = mysqli_fetch_assoc($tareas)) {
            echo "<div class='task'><strong>{$t['descripcion']}</strong><small>{$t['tipo']} - {$t['asignado']}</small>";
            if ($t['tipo'] == 'conplazo') echo "<small>{$t['inicio']} - {$t['fin']}</small>";
            echo "</div>";
          }
          echo "</div>";
        }
      ?>
    </div>
  </main>
</body>
</html>