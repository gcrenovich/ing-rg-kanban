<?php
include 'conexion.php';
$descripcion = $_POST['descripcion'];
$tipo = $_POST['tipo'];
$inicio = $_POST['inicio'] ?: null;
$fin = $_POST['fin'] ?: null;
$equipo_id = $_POST['equipo_id'];
$asignado = $_POST['asignado'];
$estado = 'pendiente';

$stmt = mysqli_prepare($conn, "INSERT INTO tareas (descripcion, tipo, inicio, fin, estado, equipo_id, asignado) VALUES (?, ?, ?, ?, ?, ?, ?)");
mysqli_stmt_bind_param($stmt, "sssssis", $descripcion, $tipo, $inicio, $fin, $estado, $equipo_id, $asignado);
mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);
header("Location: index.php");
exit();
?>