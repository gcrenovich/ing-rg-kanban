<?php
$conn = mysqli_connect("localhost", "root", "", "kanban_db");
if (!$conn) {
  die("Error de conexión: " . mysqli_connect_error());
}
?>